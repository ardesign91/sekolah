<?php
/*Untuk Rubah icon bagian ini silahkan kunjungi https://icofont.com/icons*/
/*TAB KE 1*/
$icon1  = '<i class="icofont-phone"></i>'; 
$judul1 = "Perpustakaan";
$link1	= "http://perpustakaan.smpn1cluring.sch.id/";
$des1	= "Download aplikasi e-learning di playstore";
/*TAB KE 2*/
$icon2  = '<i class="icofont-phone"></i>'; 
$judul2 = "Katalog Buku Online";
$link2	= "http://inlislite.smpn1cluring.sch.id/opac";
$des2	= "Download aplikasi e-learning di playstore";
/*TAB KE 3*/
$icon3  = '<i class="icofont-phone"></i>'; 
$judul3 = "Ebook";
$link3	= "http://inlislite.smpn1cluring.sch.id/digitalcollection";
$des3	= "Download aplikasi e-learning di playstore";
/*TAB KE 4*/
$icon4  = '<i class="icofont-phone"></i>'; 
$judul4 = "Statistik Perpustakaan";
$link4	= "http://inlislite.smpn1cluring.sch.id/statistik-perkembangan-perpustakaan";
$des4	= "Download aplikasi e-learning di playstore";

/*VIDEO*/
$video = '
<iframe width="100%" height="100%"
  src="https://www.youtube.com/embed/RWgmhrSDWAA">
</iframe>
';
/**/

/*Untuk Rubah Icon bagian ini silahkan kunjungi https://boxicons.com/ */
/*TAB SESI 1*/
$icon_1  = '<i class="bx bx-shield"></i>'; 
$judul_1 = "Perpustakaan";
$des_1	= "Download aplikasi e-learning di playstore";

/*TAB SESI s*/
$icon_2  = '<i class="bx bx-shield"></i>'; 
$judul_2 = "Perpustakaan";
$des_2	= "Download aplikasi e-learning di playstore";

/*TAB SESI 1*/
$icon_3  = '<i class="bx bx-shield"></i>'; 
$judul_3 = "Perpustakaan";
$des_3	= "Download aplikasi e-learning di playstore";

/*TAB SESI 1*/
$icon_4  = '<i class="bx bx-shield"></i>'; 
$judul_4 = "Perpustakaan";
$des_4	= "Download aplikasi e-learning di playstore";



?>